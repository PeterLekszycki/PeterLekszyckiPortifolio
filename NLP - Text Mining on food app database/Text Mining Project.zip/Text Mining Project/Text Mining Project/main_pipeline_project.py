import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import networkx as nx
import re
import nltk
from unidecode import unidecode
from nltk.tokenize.treebank import TreebankWordDetokenizer
from tqdm import tqdm
from collections import defaultdict, Counter
from sklearn.base import BaseEstimator
from sklearn import metrics


class MainPipeline(BaseEstimator):
    def __init__(self, 
                 print_output = False, 
                 no_emojis = True, 
                 no_hashtags = True,
                 hashtag_retain_words = True,
                 no_newlines = True,
                 no_urls = True,
                 no_punctuation = True,
                 no_stopwords = True,
                 custom_stopwords = [],
                 convert_diacritics = True, 
                 lowercase = True, 
                 lemmatized = True,
                 list_pos = ["n","v","a","r","s"],
                 pos_tags_list = "no_pos",
                 tokenized_output = False):
        
        self.print_output = print_output 
        self.no_emojis = no_emojis
        self.no_hashtags = no_hashtags
        self.hashtag_retain_words = hashtag_retain_words
        self.no_newlines = no_newlines
        self.no_urls = no_urls
        self.no_punctuation = no_punctuation
        self.no_stopwords = no_stopwords
        self.custom_stopwords = custom_stopwords
        self.convert_diacritics = convert_diacritics
        self.lowercase = lowercase
        self.lemmatized = lemmatized
        self.list_pos = list_pos
        self.pos_tags_list = pos_tags_list
        self.tokenized_output = tokenized_output

    def regex_cleaner(self, raw_text):

        #patterns
        newline_pattern = "(\\n)"
        hashtags_at_pattern = "([#\@@\u0040\uFF20\uFE6B])"
        hashtags_ats_and_word_pattern = "([#@]\w+)"
        emojis_pattern = "([\u2600-\u27FF])"
        url_pattern = "(?:\w+:\/{2})?(?:www)?(?:\.)?([a-z\d]+)(?:\.)([a-z\d\.]{2,})(\/[a-zA-Z\/\d]+)?"
        punctuation_pattern = "[\u0021-\u0026\u0028-\u002C\u002E-\u002F\u003A-\u003F\u005B-\u005F\u007C\u2010-\u2028\ufeff`]+"
        apostrophe_pattern = "'(?=[A-Z\s])|(?<=[a-z\.\?\!\,\s])'"
        
        if self.no_emojis == True:
            clean_text = re.sub(emojis_pattern,"",raw_text)
        else:
            clean_text = raw_text

        if self.no_hashtags == True:
            if self.hashtag_retain_words == True:
                clean_text = re.sub(hashtags_at_pattern,"",clean_text)
            else:
                clean_text = re.sub(hashtags_ats_and_word_pattern,"",clean_text)
            
        if self.no_newlines == True:
            clean_text = re.sub(newline_pattern," ",clean_text)

        if self.no_urls == True:
            clean_text = re.sub(url_pattern,"",clean_text)
        
        if self.no_punctuation == True:
            clean_text = re.sub(punctuation_pattern,"",clean_text)
            clean_text = re.sub(apostrophe_pattern,"",clean_text)

        return clean_text


    def lemmatize_all(self, token, list_pos=["n","v","a","r","s"]):
        
        wordnet_lem = nltk.stem.WordNetLemmatizer()
        for arg_1 in list_pos:
            token = wordnet_lem.lemmatize(token, arg_1)
            
        return token


    def main_pipeline(self, raw_text):

        """Preprocess strings according to the parameters"""
        if self.print_output == True:
            print("Preprocessing the following input: \n>> {}".format(raw_text))

        clean_text = self.regex_cleaner(raw_text)

        if self.print_output == True:
            print("Regex cleaner returned the following: \n>> {}".format(clean_text))

        tokenized_text = nltk.tokenize.word_tokenize(clean_text)

        tokenized_text = [re.sub("'m","am",token) for token in tokenized_text]
        tokenized_text = [re.sub("n't","not",token) for token in tokenized_text]
        tokenized_text = [re.sub("'s","is",token) for token in tokenized_text]
    
        if self.no_stopwords == True:
            stopwords = nltk.corpus.stopwords.words("english")
            tokenized_text = [item for item in tokenized_text if item.lower() not in stopwords]
        
        if self.convert_diacritics == True:
            tokenized_text = [unidecode(token) for token in tokenized_text]
            tokenized_text = [token for token in tokenized_text if token != '']

        if self.lemmatized == True:
            tokenized_text = [self.lemmatize_all(token) for token in tokenized_text]
    
        if self.no_stopwords == True:
            tokenized_text = [item for item in tokenized_text if item.lower() not in self.custom_stopwords]

        if self.pos_tags_list == "pos_list" or self.pos_tags_list == "pos_tuples" or self.pos_tags_list == "pos_dictionary":
            pos_tuples = nltk.tag.pos_tag(tokenized_text)
            pos_tags = [pos[1] for pos in pos_tuples]
        
        if self.lowercase == True:
            tokenized_text = [item.lower() for item in tokenized_text]
        
        if self.pos_tags_list == "pos_list":
            return (tokenized_text, pos_tags)
        elif self.pos_tags_list == "pos_tuples":
            return pos_tuples   
        
        else:
            if self.tokenized_output == True:
                return tokenized_text
            else:
                detokenizer = TreebankWordDetokenizer()
                detokens = detokenizer.detokenize(tokenized_text)
                if self.print_output == True:
                    print("Pipeline returning the following result: \n>> {}".format(str(detokens)))
                return str(detokens)


def word_freq_calculator(td_matrix, word_list):
    """Creates a dataframe from a term-document matrix and a word list."""
    word_counts = np.sum(td_matrix, axis=0)
    if type(word_counts) != list:
        word_counts.tolist()

    word_counts_df = pd.DataFrame({"words": word_list, "frequency": word_counts})
    word_counts_df = word_counts_df.sort_values(by=["frequency"], ascending=False)
    return word_counts_df


def plot_word_freq(word_freq, restaurant_name=None, type='words'):
    """Plots a word frequency bar plot."""
    top15 = word_freq[:15].sort_values('frequency', ascending=True)

    plt.bar(top15.index, top15.frequency, color='seagreen')

    if restaurant_name:
        plt.title(f"Top 15 most frequent {type} in {restaurant_name}'s reviews")
    else:
        plt.title(f"Top 15 most frequent {type}")
        
    plt.xlabel(type)
    plt.ylabel('Frequency')
    plt.xticks(rotation=60, fontsize=8.5)
    plt.show()
    


def cooccurrence_matrix_generator(tokens_column, target_words=None, window_size=None):
    """Creates a co-occurrence matrix given tokens and target words"""
    co_occurrences = defaultdict(Counter)
    tokenized_sentences = tokens_column.to_list()

    # If we want to consider context windows:
    if window_size:
        if not target_words:
            # We check the context window for each word 
            for sentence in tqdm(tokenized_sentences):
                for i, word in enumerate(sentence):
                    for j in range(max(0, i - window_size), min(len(sentence), i + window_size + 1)):
                        if i != j:
                            co_occurrences[word][sentence[j]] += 1

        else:
            for sentence in tqdm(tokenized_sentences):
                for i, word in enumerate(sentence):
                    for j in range(max(0, i - window_size), min(len(sentence), i + window_size + 1)):
                        if i != j and word in target_words and sentence[j] in target_words:
                            co_occurrences[word][sentence[j]] += 1

    # If we want to do simple co-occurrences
    else:
        if not target_words:  
            # We just iterate over every possible pair of words and compute their co-occurrence
            for sentence in tqdm(tokenized_sentences):
                for token_1 in sentence:
                    for token_2 in sentence:
                        if token_1 != token_2:
                            co_occurrences[token_1][token_2] += 1

        else:
            for sentence in tqdm(tokenized_sentences):
                for token_1 in sentence:
                    for token_2 in sentence:
                        if token_1 != token_2 and token_1 in target_words and token_2 in target_words:
                            co_occurrences[token_1][token_2] += 1 

    # Ensure that words are unique
    unique_words = list(set([word for sentence in tokenized_sentences for word in sentence]))

    # Initialize the co-occurrence matrix
    co_matrix = np.zeros((len(unique_words), len(unique_words)), dtype=int)

    # Populate the co-occurrence matrix
    word_index = {word: idx for idx, word in enumerate(unique_words)}
    for word, neighbors in co_occurrences.items():
        for neighbor, count in neighbors.items():
            co_matrix[word_index[word]][word_index[neighbor]] = count

    # Create a DataFrame for better readability
    co_matrix_df = pd.DataFrame(co_matrix, index=unique_words, columns=unique_words)

    sorted_columns = co_matrix_df.sum().sort_values(ascending=False).index
    co_matrix_df = co_matrix_df[sorted_columns]  # Reorder columns
    co_matrix_df = co_matrix_df.loc[sorted_columns]  # Reorder rows

    # Return the co-occurrence matrix
    return co_matrix_df



def cooccurrence_network_generator(cooccurrence_matrix_df, n_highest_words, output=None):
    """Creates a network graph given a co-occurrence matrix"""
    filtered_df = cooccurrence_matrix_df.iloc[:n_highest_words, :n_highest_words]
    graph = nx.Graph()

    # Add nodes for words and set their sizes based on frequency
    for word in filtered_df.columns:
        graph.add_node(word, size=filtered_df[word].sum())

    # Add weighted edges to the graph based on co-occurrence frequency
    for word1 in filtered_df.columns:
        for word2 in filtered_df.columns:
            if word1 != word2:
                graph.add_edge(word1, word2, weight=filtered_df.loc[word1, word2])

    figure = plt.figure(figsize=(11, 8))

    # Generate positions for the nodes
    pos = nx.spring_layout(graph, k=5)

    # Calculate edge widths based on co-occurrence frequency
    edge_weights = [0.0025 * graph[u][v]['weight'] for u, v in graph.edges()]

    # Get node sizes based on the frequency of words
    node_sizes = [data['size'] * 0.1 for _, data in graph.nodes(data=True)]

    # Create the network graph
    nx.draw_networkx_nodes(graph, pos, node_color='skyblue', node_size=node_sizes)
    nx.draw_networkx_edges(graph, pos, edge_color='gray', width=edge_weights)
    nx.draw_networkx_labels(graph, pos, font_weight='bold', font_size=10)

    plt.show() 

    if output=="return":
        return figure


def fold_score_calculator(y_pred, y_test, verbose=False):
    """Compute accuracy, weighted precision, recall and f1-score for a fold"""
    acc = metrics.accuracy_score(y_test, y_pred)
    prec = metrics.precision_score(y_test, y_pred, average="weighted")
    recall = metrics.recall_score(y_test, y_pred, average="weighted")
    f1 = metrics.f1_score(y_test, y_pred, average="weighted")
    
    if verbose == True:
        print("Accuracy: {} \nPrecision: {} \nRecall: {} \nF1: {}".format(acc,prec,recall,f1))
        
    return [round(acc, 3), round(prec, 3), round(recall, 3), round(f1, 3)]
